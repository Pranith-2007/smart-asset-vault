Smart Asset Vault — landing redesign + screenshots

Contents:
- src/landing/: redesigned landing-page components supplied by Claude
- src/data/landingScreenshots.ts: screenshot data mapping for the redesigned Hero and Showcase
- assets/landing/: five supplied mobile screenshots used by the phone mockups

Integration notes:
1. Copy the contents of src/landing/ into your frontend/src/landing/ folder.
2. Copy src/data/landingScreenshots.ts into frontend/src/data/landingScreenshots.ts (back up your existing file first).
3. Copy assets/landing/ into frontend/assets/landing/.
4. Review imports and app integration before replacing existing files; preserve your current sign-in and portal callbacks.
5. Run npm run typecheck and preview with npx expo start --web before committing.

Screenshot mapping:
- hero-home.png -> hero phone
- documents-list.png -> showcase 01
- access-history.png -> showcase 02
- document-detail.png -> showcase 03
- portal-selection.png -> showcase 04

This bundle does not include node_modules, secrets, environment files, or Git history.
